export interface HeaderMenus {
  showAuthSection: boolean;
  showNoAuthSection: boolean;
}
