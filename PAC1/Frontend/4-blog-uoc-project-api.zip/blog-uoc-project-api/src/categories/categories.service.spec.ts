import { CategoriesService } from './categories.service';

describe('CategoriesService', () => {
  it('should be defined', () => {
    expect(new CategoriesService()).toBeDefined();
  });
});
