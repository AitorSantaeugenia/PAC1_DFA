import { ValidCategoryIdPipe } from './valid-category-id.pipe';

describe('ValidCategoryIdPipe', () => {
  it('should be defined', () => {
    expect(new ValidCategoryIdPipe()).toBeDefined();
  });
});
