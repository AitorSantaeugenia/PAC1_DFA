import { ExistCategoryTitlePipe } from './exist-category-title.pipe';

describe('ExistCategoryTitlePipe', () => {
  it('should be defined', () => {
    expect(new ExistCategoryTitlePipe()).toBeDefined();
  });
});
