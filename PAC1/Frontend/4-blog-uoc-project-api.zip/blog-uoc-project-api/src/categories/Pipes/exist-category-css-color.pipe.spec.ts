import { ExistCategoryCssColorPipe } from './exist-category-css-color.pipe';

describe('ExistCategoryCssColorPipe', () => {
  it('should be defined', () => {
    expect(new ExistCategoryCssColorPipe()).toBeDefined();
  });
});
