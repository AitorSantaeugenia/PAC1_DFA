import { CategoryDto } from './category.dto';

describe('CategoryDto', () => {
  it('should be defined', () => {
    expect(new CategoryDto()).toBeDefined();
  });
});
