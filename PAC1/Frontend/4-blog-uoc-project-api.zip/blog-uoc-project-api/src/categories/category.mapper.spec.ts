import { CategoryMapper } from './category.mapper';

describe('CategoryMapper', () => {
  it('should be defined', () => {
    expect(new CategoryMapper()).toBeDefined();
  });
});
