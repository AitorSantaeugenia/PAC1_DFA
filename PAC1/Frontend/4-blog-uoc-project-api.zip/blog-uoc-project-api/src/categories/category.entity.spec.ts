import { CategoryEntity } from './category.entity';

describe('CategoryEntity', () => {
  it('should be defined', () => {
    expect(new CategoryEntity()).toBeDefined();
  });
});
