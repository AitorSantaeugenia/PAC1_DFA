import { ValidUserIdPipe } from './valid-user-id.pipe';

describe('ValidUserIdPipe', () => {
  it('should be defined', () => {
    expect(new ValidUserIdPipe()).toBeDefined();
  });
});
