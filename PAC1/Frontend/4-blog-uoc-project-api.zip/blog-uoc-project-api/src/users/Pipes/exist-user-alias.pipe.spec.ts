import { ExistUserAliasPipe } from './exist-user-alias.pipe';

describe('ExistUserAliasPipe', () => {
  it('should be defined', () => {
    expect(new ExistUserAliasPipe()).toBeDefined();
  });
});
