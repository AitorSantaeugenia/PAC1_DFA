import { ExistUserEmailPipe } from './exist-user-email.pipe';

describe('ExistUserEmailPipe', () => {
  it('should be defined', () => {
    expect(new ExistUserEmailPipe()).toBeDefined();
  });
});
