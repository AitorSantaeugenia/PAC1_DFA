import { UserMapper } from './user.mapper';

describe('UserMapper', () => {
  it('should be defined', () => {
    expect(new UserMapper()).toBeDefined();
  });
});
