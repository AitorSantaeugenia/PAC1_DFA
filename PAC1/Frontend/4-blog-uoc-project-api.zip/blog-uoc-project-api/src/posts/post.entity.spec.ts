import { PostEntity } from './post.entity';

describe('PostEntity', () => {
  it('should be defined', () => {
    expect(new PostEntity()).toBeDefined();
  });
});
