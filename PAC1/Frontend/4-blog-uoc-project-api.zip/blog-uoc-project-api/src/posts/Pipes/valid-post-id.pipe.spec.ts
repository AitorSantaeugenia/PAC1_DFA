import { ValidPostIdPipe } from './valid-post-id.pipe';

describe('ValidPostIdPipe', () => {
  it('should be defined', () => {
    expect(new ValidPostIdPipe()).toBeDefined();
  });
});
