import { PostsService } from './posts.service';

describe('PostsService', () => {
  it('should be defined', () => {
    expect(new PostsService()).toBeDefined();
  });
});
