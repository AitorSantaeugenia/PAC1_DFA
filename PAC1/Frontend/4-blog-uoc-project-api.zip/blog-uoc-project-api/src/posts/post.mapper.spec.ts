import { PostMapper } from './post.mapper';

describe('PostMapper', () => {
  it('should be defined', () => {
    expect(new PostMapper()).toBeDefined();
  });
});
